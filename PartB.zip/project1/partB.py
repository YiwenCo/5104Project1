#partB
import pandas as pd
import numpy as np
df = df = pd.read_csv(r"C:\data mining\project1\Concrete_Data.csv")#import dataset

#look into the data and check if it is open properly
print(df.shape)
print(df.head(10))
print(df.columns)

#split the dataset into training set and testing set
df_test = df.iloc[500:630] # use row 501-630 as testing set
df_train = pd.concat([df.iloc[:500], df.iloc[630:]], ignore_index=True) #remains are training set

# mark predictors and response value
x_train = df_train.iloc[:, 0:8].values
y_train = df_train.iloc[:, -1].values

x_test = df_test.iloc[:, 0:8].values
y_test = df_test.iloc[:, -1].values

#tool function: mse, R^2, standardize
#standardize
def standardize_1d(x_train, x_test):
    mu = x_train.mean()
    sigma = x_train.std()
    if sigma == 0:
        sigma = 1.0
    return (x_train - mu) / sigma, (x_test - mu) / sigma

def standardize_2d(x_train, x_test):
    mu = x_train.mean(axis = 0)
    sigma = x_train.std(axis = 0)

    for i in range(len(sigma)):
        if sigma[i] == 0:
            sigma[i] = 1

    return (x_train-mu)/sigma, (x_test-mu)/sigma

#mse
def MSE(y_true, y_pred):
    return np.mean((y_pred-y_true)**2)

#R^2
def r2(y_true, y_pred):
    var=np.var(y_true)
    return 1 - MSE(y_true,y_pred) / var

#gradient descent
# univariate gradient descent
def univariate_gradient_descent(x,y,lr=1e-3, iteration = 10000):
    """
    x, y, 
    m = 0
    b = 0
    return m , b
    """
    m = 0
    #b = 0
    b = float(np.mean(y_train)) # when we use raw data as predictor we initiate b as mean value of y
    n = len(y)
    for i in range(iteration):
        y_pred = m*x + b
        err = y - y_pred
        dm = (-2/n) * sum(x * err) # dm = dmse/dm
        db = (-2/n) * sum(err) # db = dmse/db
        m = m-lr*dm # m_new = m_old - lr* dmse/dm
        b = b-lr*db # b_new = b_old - lr* dmse/db
    return m,b

# competetion of mse, r^2 for taraining\testing dataset
def univariate_feature_print():
    """
    print("x_train dtype:", x_train.dtype)
    print("y_train dtype:", y_train.dtype)
    """
    for i in range(8):
        x_cp_train = x_train[:,i] #feature we select
        x_cp_test = x_test[:,i]

        """
        #standardized predictor/raw responser
        x_train_std, x_test_std = standardize_1d(x_cp_train, x_cp_test)
        m,b=univariate_gradient_descent(x_train_std,y_train,lr=1e-3, iteration = 10000)
        y_cp_train = m * x_train_std + b
        y_cp_test = m * x_test_std + b
        """
        #raw predictor/responser
        m,b=univariate_gradient_descent(x_cp_train,y_train,lr=1e-6, iteration = 200000) # initiate b as mean of y
        y_cp_train = m * x_cp_train + b
        y_cp_test = m * x_cp_test + b


        """
        print("y_cp_train dtype:", y_cp_train.dtype)
        """
        print("Feature", i+1)
        print("m =", m)
        print("b =", b)
        print("Train MSE:", MSE(y_train,y_cp_train))
        print("Train R2:", r2(y_train, y_cp_train))
        print("Test  MSE:", MSE(y_test, y_cp_test))
        print("Test R2:", r2(y_test, y_cp_test))
        


# run the algorithm
#univariate_feature_print()



def multivariate_gradient_decent(X, y, lr=1e-7, iteration=10000):
   """
    X,: shape (n, p)
    y: shape (n,)
    return M , b
   """
   n,p = X.shape
   """"
   parameter in code test 1,2
   M = np.ones(p)
   b = 1.0
   """
   
   M = np.zeros(p)
   b = 0.0

   for i in range(iteration):
       y_pred = X @ M + b
       err = y - y_pred
       dM = (-2/n) * (X.T @ err)
       db = (-2/n) * np.sum(err)
       M = M - lr * dM
       b = b - lr * db
   return M, b

"""
code test 1
def multivariate_code_test1():
    x=np.array([[3, 4, 5]])
    y = np.array([4])
    lr = 0.1
    M, b = multivariate_gradient_decent(x, y, lr=0.1, iteration=1)
    print("M:",M)
    print("b:",b)
    """

""""
code test 2
def multivariate_code_test2():
    x=np.array([[3, 4, 4],
                [4,2,1],
                [10,2,5],
                [3,4,5],
                [11,1,1]])
    y = np.array([3,2,8,4,5])
    lr = 0.1
    M, b = multivariate_gradient_decent(x, y, lr=0.1, iteration=1)
    print("M:",M)
    print("b:",b)
    """

#run test code1
#multivariate_code_test1()

#run test code2
#multivariate_code_test2()



def multivariate_feature_print_raw():
    M, b = multivariate_gradient_decent(x_train, y_train, lr=1e-7, iteration=10000)
    y_train_pred = x_train @ M + b
    y_test_pred = x_test @ M + b
    print("answer for set 1")
    print("M:",M)
    print("b:",b)
    print("Train MSE:", MSE(y_train,y_train_pred))
    print("Train R2:", r2(y_train, y_train_pred))
    print("Test  MSE:", MSE(y_test, y_test_pred))
    print("Test  R2:", r2(y_test, y_test_pred))


def multivariate_feature_print_standardized():
    X_train_std, X_test_std = standardize_2d(x_train, x_test)
    M, b = multivariate_gradient_decent(X_train_std, y_train, lr=1e-3, iteration=20000)
    y_train_pred = X_train_std @ M + b
    y_test_pred = X_test_std @ M + b
    print("answer for set 2")
    print("M:",M)
    print("b:",b)
    print("Train MSE:", MSE(y_train, y_train_pred))
    print("Train R2:", r2(y_train, y_train_pred))
    print("Test  MSE:", MSE(y_test, y_test_pred))
    print("Test  R2:", r2(y_test, y_test_pred))


print("SET2 train columns:", list(df_train.columns))
print("SET2 test  columns:", list(df_test.columns))
# run algorithm
multivariate_feature_print_raw()
multivariate_feature_print_standardized()


       













